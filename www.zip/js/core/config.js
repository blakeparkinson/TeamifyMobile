/* jshint ignore:start */


angular.module('app.core')
.
constant('baseApiUrl', 'http://teamify-development.herokuapp.com').constant('deployChannel', 'dev');


/* jshint ignore:end */